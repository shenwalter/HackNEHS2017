﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spinner : MonoBehaviour {


    public GameObject flagPos;

    private Rigidbody rb;

    // Use this for initialization
    void Start ()
    {
        rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
        applyForce();
	}

    void applyForce()
    {
        Vector3 diff = flagPos.transform.position - GetComponent<Rigidbody>().position;
        diff = 10 * diff / diff.magnitude;
        rb.velocity = diff;
    }

}
