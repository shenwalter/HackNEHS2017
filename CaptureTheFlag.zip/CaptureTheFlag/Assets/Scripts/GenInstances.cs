﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenInstances : MonoBehaviour {
    public GameObject pickUps;
    float speed = 5;
    int numEnemies = 100;

    void Start()
    {
        for (int i = 0; i < numEnemies; i++)
        {
            Vector3 pLoc = new Vector3(10 * Random.value, 100 + 10 * Random.value, 10 * Random.value);
            Instantiate(pickUps, pLoc, Quaternion.identity);
        }
    }
}
 

