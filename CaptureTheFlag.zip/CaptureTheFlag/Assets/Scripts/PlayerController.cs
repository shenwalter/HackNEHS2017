﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody rb;
    
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && GetComponent<Rigidbody>().velocity[1] < 10)
        {
            Vector3 jump = new Vector3 (0.0f, 200.0f, 0.0f);
            print(GetComponent<Rigidbody>().position);
            rb.AddForce(jump);
        }
    }


    void FixedUpdate()
    {

        float moveHorizontal = 20*Input.GetAxis("Horizontal");
        float moveVertical = 20*Input.GetAxis("Vertical");

        Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

        rb.AddForce(movement);

    }

    
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Flag"))
        {
            other.gameObject.SetActive (false);
        }
    }

}