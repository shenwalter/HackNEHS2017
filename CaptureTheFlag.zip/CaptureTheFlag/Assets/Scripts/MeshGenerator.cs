﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshGenerator : MonoBehaviour {



    /*

    public static Vector3[] vertices = {
        new Vector3(x, y, 1);
        new Vector3(x, y, 1);
        new Vector3(x, y, 1);
        new Vector3(x, y, 1);
        new Vector3(x, y, 1);
        new Vector3(x, y, 1);
        new Vector3(x, y, 1);
        new Vector3(x, y, 1);

}

    public Material mat;

    float height = 1;
    float width = 1;

	// Use this for initialization
	void Start () {
		Mesh mesh = new Mesh();

        Vector3[] vertices = new Vector3[100];


        for (int i = 0; i < 100; i++)
        {
            vertices[i] = new Vector3(-width*i, -height*i);
        }    

        mesh.vertices = vertices;

        mesh.triangles = new int[] { 0, 1, 2, 0, 2, 3 };

        GetComponent<MeshFilter>().mesh = mesh;

    }

    // Update is called once per frame
    void Update () {
		
	}*/
}
