﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TerainGeneration : MonoBehaviour {

    public int depth = 20;
    public int width = 256;
    public int height = 256;

    public float scale = 20f;


	// Use this for initialization
	void Start () {
        Terrain terrain = GetComponent<Terrain>();
        terrain.terrainData = GenerateTerrain(terrain.terrainData);
	}


    TerrainData GenerateTerrain (TerrainData terrainData)
    {
        terrainData.size = new Vector3(width, depth, height);

        terrainData.SetHeights(0, 0, GenerateHeights());
        return terrainData;
    }


    float[,] GenerateHeights()
    {
        float[,] heights = new float[width, height];
        int ctx = 0;
        int cty = 0;
        int[] InitPoint = { 0, 0 };
        int region = 0;
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (ctx % width - InitPoint[0] < region && cty - InitPoint[1] < region)
                {
                    heights[x, y] = CalculateHeight(x, y, true);
                }
                else
                {
                    heights[x, y] = CalculateHeight(x, y, false);
                }

                if (ctx > 1000 && cty > 10)
                {
                    cty = 0;
                    ctx = 0;
                    if (Random.value < 0.2)
                    {
                        region = 100;
                    }
                    else
                    {
                        region = 0;
                    }
                }

                cty += 1;
            }
            ctx += 1;
        }
        return heights;
    }


    float CalculateHeight(int x, int y, bool intesneSection)
    {
        float noiseiness = 1.6f;
        float thesize = 1.0f;
        if (intesneSection)
        {
            thesize *= 100;
            noiseiness *= 0.01f;
        }
        float xCoord = x * scale / width;
        float yCoord = y * scale / height;
        return thesize * Mathf.PerlinNoise(noiseiness*xCoord, noiseiness*yCoord);
    }

}
